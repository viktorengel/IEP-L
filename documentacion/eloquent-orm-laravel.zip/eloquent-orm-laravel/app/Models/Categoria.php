<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Categoria extends Model
{
    use HasFactory;

    /*
    // categorias
    protected $table = "categorias";
    // id
    protected $primaryKey = 'idcat';
    public $incrementing = false;
    protected $keyType = 'string';

    // created_at, updated_at
    public $timestamps = false;

    */

    public function productos()
    {
        return $this->hasMany(Producto::class);
    }
}
