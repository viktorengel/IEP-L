<h1>Editar producto</h1>

<form action="/producto/<?php echo e($producto->id); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <label for="">Ingrese Nombre</label>
    <input type="text" name="nombre" value="<?php echo e($producto->nombre); ?>">
    <br>
    <label for="">Ingrese Precio</label>
    <input type="number" name="precio" step="0.01" value="<?php echo e($producto->precio); ?>">
    <br>
    <label for="">Cantidad</label>
    <input type="number" name="cantidad" value="<?php echo e($producto->cantidad); ?>">
    <br>
    <label for="">Ingrese Imagen</label>
    <input type="text" name="imagen" value="<?php echo e($producto->imagen); ?>">

    <br>
    <label for="">Ingrese Descripcion</label>
    <textarea name="descripcion" id="" cols="30" rows="10"><?php echo e($producto->descripcion); ?></textarea>
    <br>
    <input type="submit" value="Modificar">
</form><?php /**PATH D:\cursos\cursoLaravel\sql-queryBuilder\resources\views/producto/editar.blade.php ENDPATH**/ ?>