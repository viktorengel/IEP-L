

<a href="/producto/crear">Nuevo Producto</a>

<table border="1">
    <tr>
        <td>ID</td>
        <td>NOMBRE</td>
        <td>PRECIO</td>
        <td>CANTIDAD</td>
        <td>ST</td>
        <td>IMAGEN</td>
        <td>ACCION</td>
    </tr>
    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($prod->id); ?></td>
            <td><?php echo e($prod->nombre); ?></td>
            <td><?php echo e($prod->precio); ?></td>
            <td><?php echo e($prod->cantidad); ?></td>
            <td><?php echo e($prod->cantidad *  $prod->precio); ?></td>
            <td>
                <img src="<?php echo e($prod->imagen); ?>" alt="" width="100px">
            </td>
            <td><a href="/producto/<?php echo e($prod->id); ?>/editar">editar</a></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH D:\cursos\cursoLaravel\sql-queryBuilder\resources\views/producto/listar.blade.php ENDPATH**/ ?>