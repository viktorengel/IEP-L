<?php

use App\Http\Controllers\ProductoController;
use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    return view('welcome');
});

Route::get("/producto", [ProductoController::class, "listar"]);

Route::get("/producto/crear", [ProductoController::class, "crear"]); // cargar el form (creacion)
Route::post("/producto", [ProductoController::class, "guardar"]);

Route::get("/producto/{id}", [ProductoController::class, "mostrar"]);

Route::get("/producto/{id}/editar", [ProductoController::class, "editar"]); // cargar el form (edicion)
Route::put("/producto/{id}", [ProductoController::class, "modificar"]);

Route::delete("/producto/{id}", [ProductoController::class, "eliminar"]);
