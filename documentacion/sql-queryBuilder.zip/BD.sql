
CREATE DATABASE laravel_sql_query_builder;
use laravel_sql_query_builder;

CREATE TABLE productos(
    id INT auto_increment primary key,
    nombre varchar(100) NOT NULL,
    precio decimal(10, 2),
    cantidad INT NOT NULL,
    imagen varchar(255),
    descripcion text
);
